<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Barangmasuk extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Barang Masuk";
        $data['barangmasuk'] = $this->admin->getBarangMasuk();
        $this->template->load('templates/dashboard', 'barang_masuk/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('tanggal_masuk', 'Tanggal Masuk', 'required|trim');
        $this->form_validation->set_rules('id_pic', 'pic', 'required');
        $this->form_validation->set_rules('barang_id', 'Barang', 'required');
        $this->form_validation->set_rules('id_materi', 'materi', 'required');
        $this->form_validation->set_rules('jumlah_masuk', 'Jumlah Masuk', 'required|trim|numeric|greater_than[0]');
    
        
    }
    

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Barang Masuk";
            $data['pic'] = $this->admin->get('pic');
            $data['barang'] = $this->admin->get('barang');
            $data['materi'] = $this->admin->get('materi');

            // Mendapatkan dan men-generate kode transaksi barang masuk
            $kode = 'T-BM-' . uniqid();
            $kode_terakhir = $this->admin->getMax('barang_masuk', 'id_barang_masuk', $kode);
            $kode_tambah = substr($kode_terakhir, -5, 5);
            $kode_tambah++;
            $number = str_pad($kode_tambah, 5, '0', STR_PAD_LEFT);
            $data['id_barang_masuk'] = $kode . $number;

            $this->template->load('templates/dashboard', 'barang_masuk/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('barang_masuk', $input);

            if ($insert) {
                set_pesan('data berhasil disimpan.');
                redirect('barangmasuk');
            } else {
                set_pesan('Opps ada kesalahan!');
                redirect('barangmasuk/add');
            }
        }
    }




    public function edit($getId)
    {
    // Mendekode nilai $getId untuk mendapatkan id_barang_keluar
    $masuk_barang_id = html_escape($getId);

    // Validasi form input
    $this->_validasi();

    if ($this->form_validation->run() == false) {
        $data['title'] = "Barang Masuk";
        $data['pic'] = $this->admin->get('pic');
        $data['barang'] = $this->admin->get('barang', ['masuk_barang_id' => $masuk_barang_id]);
        $data['materi'] = $this->admin->get('materi');

        $this->template->load('templates/dashboard', 'barang_masuk/edit', $data);
    } else {
        $input = $this->input->post(null, true);
        $update = $this->admin->update('barang_masuk', 'id_barang_masuk', $masuk_barang_id, $input);

        if ($update) {
            set_pesan('data berhasil disimpan');
            redirect('barang_masuk'); // Ganti "barang" menjadi "barang_keluar" jika ini adalah halaman untuk CRUD barang keluar
        } else {
            set_pesan('gagal menyimpan data');
            redirect('barang_masuk/edit/' . $getId); // Ganti "barang" menjadi "barang_keluar" jika ini adalah halaman untuk CRUD barang keluar
        }
    }
    }


    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('barang_masuk', 'id_barang_masuk', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('barangmasuk');
    }
}
