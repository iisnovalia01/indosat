<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Barangkeluar extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Barang Keluar";
        $data['barangkeluar'] = $this->admin->getBarangkeluar();
        $this->template->load('templates/dashboard', 'barang_keluar/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('tanggal_keluar', 'Tanggal Keluar', 'required|trim');
        $this->form_validation->set_rules('id_pic', 'pic', 'required');
        $this->form_validation->set_rules('barang_id', 'Barang', 'required');
        $this->form_validation->set_rules('id_materi', 'materi', 'required');

        $input = $this->input->post('barang_id', true);
        $stokData = $this->admin->get('barang', ['id_barang' => $input]);
        $stok = isset($stokData['stok']) ? $stokData['stok'] : 0;
        $stok_valid = $stok + 1;

        $this->form_validation->set_rules(
            'jumlah_keluar',
            'Jumlah Keluar',
            "required|trim|numeric|greater_than[0]|less_than[{$stok_valid}]",
            [
                'less_than' => "Jumlah Keluar tidak boleh lebih dari {$stok}"
            ]
        );

    }


    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Barang Keluar";
            $data['pic'] = $this->admin->get('pic');
            $data['barang'] = $this->admin->get('barang');
            $data['materi'] = $this->admin->get('materi');
            


            // Mendapatkan dan men-generate kode transaksi barang keluar
            $kode = 'T-BK-' .  uniqid();
            $kode_terakhir = $this->admin->getMax('barang_keluar', 'id_barang_keluar', $kode);
            $kode_tambah = substr($kode_terakhir, -5, 5);
            $kode_tambah++;
            $number = str_pad($kode_tambah, 5, '0', STR_PAD_LEFT);
            $data['id_barang_keluar'] = $kode . $number;

            $this->template->load('templates/dashboard', 'barang_keluar/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('barang_keluar', $input);

            if ($insert) {
                set_pesan('data berhasil disimpan.');
                redirect('barangkeluar');
            } else {
                set_pesan('Opps ada kesalahan!');
                redirect('barangkeluar/add');
            }
        }
    }

    
    public function edit($getId)
    {
    // Mendekode nilai $getId untuk mendapatkan id_barang_keluar
    $id_barang_keluar = html_escape($getId);

    // Validasi form input
    $this->_validasi();

    if ($this->form_validation->run() == false) {
        $data['title'] = "Barang Keluar";
        $data['pic'] = $this->admin->get('pic');
        $data['barang'] = $this->admin->get('barang', ['id_barang_keluar' => $id_barang_keluar]);
        $data['materi'] = $this->admin->get('materi');

        $this->template->load('templates/dashboard', 'barang_keluar/edit', $data);
    } else {
        $input = $this->input->post(null, true);
        $update = $this->admin->update('barang_keluar', 'id_barang_keluar', $id_barang_keluar, $input);

        if ($update) {
            set_pesan('data berhasil disimpan');
            redirect('barang_keluar'); // Ganti "barang" menjadi "barang_keluar" jika ini adalah halaman untuk CRUD barang keluar
        } else {
            set_pesan('gagal menyimpan data');
            redirect('barang_keluar/edit/' . $getId); // Ganti "barang" menjadi "barang_keluar" jika ini adalah halaman untuk CRUD barang keluar
        }
    }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('barang_keluar', 'id_barang_keluar', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('barangkeluar');
    }
}
