<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Materi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Materi";
        $data['materi'] = $this->admin->get('materi');
        $this->template->load('templates/dashboard', 'materi/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama_materi', 'Nama Materi', 'required|trim');
    }

    public function add()
    {
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Materi";
            $this->template->load('templates/dashboard', 'materi/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('materi', $input);
            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('Materi');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('materi/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Materi";
            $data['materi'] = $this->admin->get('materi', ['id_materi' => $id]);
            $this->template->load('templates/dashboard', 'materi/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('materi', 'id_materi', $id, $input);
            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('materi');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('materi/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('materi', 'id_materi', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('materi');
    }
}
