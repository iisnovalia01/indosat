<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    public function get($table, $data = null, $where = null)
    {
        if ($data != null) {
            return $this->db->get_where($table, $data)->row_array();
        } else {
            return $this->db->get_where($table, $where)->result_array();
        }
    }

    public function update($table, $pk, $id, $data)
    {
        $this->db->where($pk, $id);
        return $this->db->update($table, $data);
    }

    public function insert($table, $data, $batch = false)
    {
        return $batch ? $this->db->insert_batch($table, $data) : $this->db->insert($table, $data);
    }

    public function delete($table, $pk, $id)
    {
        return $this->db->delete($table, [$pk => $id]);
    }

    public function getUsers($id)
    {
        /**
         * ID disini adalah untuk data yang tidak ingin ditampilkan. 
         * Maksud saya disini adalah 
         * tidak ingin menampilkan data user yang digunakan, 
         * pada managemen data user
         */
        $this->db->where('id_user !=', $id);
        return $this->db->get('user')->result_array();
    }

    public function getBarang()
    {
        $this->db->join('materi m', 'b.id_materi = m.id_materi');
        $this->db->order_by('id_barang');
        return $this->db->get('barang b')->result_array();
    }

    public function getBarangMasuk($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.user_id = u.id_user');
        $this->db->join('pic p', 'bm.id_pic= p.id_pic');
        $this->db->join('barang b', 'bm.barang_id = b.id_barang');
        $this->db->join('materi m' ,'bm.id_materi= m.id_materi');
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($id_barang != null) {
            $this->db->where('id_barang', $id_barang);
        }

        if ($range != null) {
            $this->db->where('tanggal_masuk' . ' >=', $range['mulai']);
            $this->db->where('tanggal_masuk' . ' <=', $range['akhir']);
        }

        $this->db->order_by('id_barang_masuk', 'DESC');
        return $this->db->get('barang_masuk bm')->result_array();
    }


        public function getBarangkeluar($limit = null, $id_barang = null, $range = null)
    {
        $this->db->select('bk.*, u.nama AS nama_user, b.nama_barang, p.nama_pic, m.nama_materi');
        $this->db->from('barang_keluar bk');
        $this->db->join('user u', 'bk.user_id = u.id_user');
        $this->db->join('barang b', 'bk.barang_id = b.id_barang');
        $this->db->join('pic p', 'bk.id_pic= p.id_pic');
        $this->db->join('materi m','bk.id_materi = m.id_materi');

        if ($limit !== null) {
            $this->db->limit($limit);
        }

        if ($id_barang !== null) {
            $this->db->where('b.id_barang', $id_barang);
        }

        if ($range !== null && isset($range['mulai']) && isset($range['akhir'])) {
            $this->db->where('bk.tanggal_keluar >=', $range['mulai']);
            $this->db->where('bk.tanggal_keluar <=', $range['akhir']);
        }

        $this->db->order_by('bk.id_barang_keluar', 'DESC');
        return $this->db->get()->result_array();
    }

        public function getMax($table, $field, $prefix = '')
        {
            $this->db->select_max($field);
            $this->db->like($field, $prefix, 'after');
            $query = $this->db->get($table)->row_array();
            $maxId = $query[$field];
    
            if ($maxId == null) {
                return $prefix . '000001';
            } else {
                $number = (int)substr($maxId, strlen($prefix));
                $number++;
                $number = str_pad($number, 6, '0', STR_PAD_LEFT);
                return $prefix . $number;
            }
        }
    

    public function sum($table, $field)
    {
        $this->db->select_sum($field);
        return $this->db->get($table)->row_array()[$field];
    }

    public function min($table, $field, $min)
    {
        $field = $field . ' <=';
        $this->db->where($field, $min);
        return $this->db->get($table)->result_array();
    }

    public function chartBarangMasuk($bulan)
    {
        $like = 'T-BM-' . date('y') . $bulan;
        $this->db->like('id_barang_masuk', $like, 'after');
        return count($this->db->get('barang_masuk')->result_array());
    }

    public function chartBarangKeluar($bulan)
    {
        $like = 'T-BK-' . date('y') . $bulan;
        $this->db->like('id_barang_keluar', $like, 'after');
        return count($this->db->get('barang_keluar')->result_array());
    }

    public function cekStok($id)
    {
        $this->db->join('materi m', 'b.materi_id=m.id_materi');
        return $this->db->get_where('barang b', ['id_barang' => $id])->row_array();
    }
}
